import { IconPackConfig } from "./config.interface";
import * as packs from "./packs/index";

export const configs: IconPackConfig[] = Object.values(packs);
