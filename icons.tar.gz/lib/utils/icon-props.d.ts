import { QwikIntrinsicElements } from "@builder.io/qwik";
export type IconProps = QwikIntrinsicElements["svg"];
